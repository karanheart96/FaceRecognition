import subprocess as sp
global sp
p1=sp.Popen(['python','3.py'])
global p1
